-- Crear la tabla
CREATE TABLE datos_personales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50),
    apellido VARCHAR(50),
    telefono VARCHAR(20),
    correo_electronico VARCHAR(100),
    direccion VARCHAR(100)
);

-- Insertar las 10 entradas
INSERT INTO datos_personales (nombre, apellido, telefono, correo_electronico, direccion)
VALUES
    ('Juan', 'Pérez', '123456789', 'juan@example.com', 'Calle Principal 123'),
    ('María', 'López', '987654321', 'maria@example.com', 'Avenida Central 456'),
    ('Carlos', 'Gómez', '555555555', 'carlos@example.com', 'Carrera 7 890'),
    ('Laura', 'García', '111111111', 'laura@example.com', 'Calle 10 111'),
    ('Pedro', 'Rodríguez', '999999999', 'pedro@example.com', 'Avenida Libertador 789'),
    ('Ana', 'Martínez', '444444444', 'ana@example.com', 'Calle 5 222'),
    ('Luis', 'Hernández', '222222222', 'luis@example.com', 'Carrera 15 333'),
    ('Marta', 'Torres', '777777777', 'marta@example.com', 'Avenida Sur 456'),
    ('Diego', 'Ramírez', '666666666', 'diego@example.com', 'Calle 20 444'),
    ('Lucía', 'Sánchez', '888888888', 'lucia@example.com', 'Carrera Norte 555');